function App() {
  return <h1>대출 상관 계산기</h1>;
}

export default App;
