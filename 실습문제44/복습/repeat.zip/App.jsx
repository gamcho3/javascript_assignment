function App() {
  return (
    <div className="App">
      <div className="profile-card">
        <img src="" alt="" className="profile-avatar" />
        <h2 className="profile-name">이름</h2>
        <p className="profile-age">나이</p>
        <p className="profile-email">이메일</p>
        <ul className="profile-card-children">
          <li>낚시</li>
          <li>노래</li>
        </ul>
      </div>
    </div>
  );
}

export default App;
