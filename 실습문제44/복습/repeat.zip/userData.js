export default [
  {
    name: "이수민",
    age: 28,
    email: "suminlee@example.com",
    avatarUrl: "https://randomuser.me/api/portraits/women/29.jpg",
    hobbies: ["요리"],
  },
  {
    name: "김영호",
    age: 34,
    email: "youngho.kim@example.com",
    avatarUrl: "https://randomuser.me/api/portraits/men/34.jpg",
    hobbies: ["영화 감상", "자전거 타기"],
  },
  {
    name: "박지현",
    age: 26,
    email: "jihyun.park@example.com",
    avatarUrl: "https://randomuser.me/api/portraits/women/26.jpg",
    hobbies: ["음악 감상", "사진 촬영", "독서"],
  },
  {
    name: "최민수",
    age: 31,
    email: "minsue.choi@example.com",
    avatarUrl: "https://randomuser.me/api/portraits/men/31.jpg",
    hobbies: ["독서", "테니스", "영화 감상", "게임"],
  },
  {
    name: "윤서영",
    age: 27,
    email: "seoyoung.yoon@example.com",
    avatarUrl: "https://randomuser.me/api/portraits/women/27.jpg",
    hobbies: ["여행", "캘리그래피", "요가", "베이킹", "사진 촬영"],
  },
];
