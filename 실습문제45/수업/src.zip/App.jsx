import componentImg from "./assets/components.png";
import confgImg from "./assets/config.png";
import jsxImg from "./assets/jsx-ui.png";
import Card from "./components/Card";
import TabButton from "./components/TabButton";
import { useState } from "react";
function App() {
  const [selectedTopic, setSelectedTopic] = useState("데이터를 입력해주세요");

  function handleSelect(topic) {
    setSelectedTopic(topic);
  }

  return (
    <div className="app">
      <h1>React Props 연습</h1>
      <div className="card-container">
        <Card
          title="React Props"
          content="React props는 컴포넌트에 데이터를 전달하는 방법입니다."
          backgroundColor="#ffddc1"
          textColor="#333"
          img={componentImg}
        />

        <Card
          title="Reusable Component"
          content="Card 컴포넌트를 재사용하여 다양한 데이터를 보여줄 수 있습니다."
          backgroundColor="#c1d7ff"
          textColor="#333"
          img={confgImg}
        />
        <Card
          title="Dynamic Styling"
          content="props를 이용해 동적으로 스타일을 변경할 수 있습니다."
          backgroundColor="#d1ffc1"
          textColor="#333"
          img={jsxImg}
        />
      </div>
      <section className="example">
        <h2>예시</h2>
        <menu>
          <TabButton onSelect={() => handleSelect("component")}>
            데이터 전달
          </TabButton>
          <TabButton onSelect={() => handleSelect("props")}>
            재사용 컴포넌트
          </TabButton>
          <TabButton onSelect={() => handleSelect("styling")}>
            동적 스타일링
          </TabButton>
        </menu>
        {selectedTopic}
      </section>
    </div>
  );
}

export default App;
