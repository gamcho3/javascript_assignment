// CoreConcept.jsx
import Card from "./card/Card";
import { CARD_DATA } from "../card_data";

export default function CoreConcept() {
  return (
    <section className="card-container">
      {CARD_DATA.map((card, index) => {
        return (
          <Card
            title={card.title}
            content={card.content}
            backgroundColor={card.backgroundColor}
            textColor={card.textColor}
            img={card.img}
            key={index}
          />
        );
      })}
    </section>
  );
}
