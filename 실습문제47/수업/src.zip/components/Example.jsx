import TabButton from "./TabButton";
import { data } from "../data";
import { useState } from "react";
import Section from "./Section";
import Tabs from "./Tabs";
export default function Example() {
  const [selectedLabel, setSelectedLabel] = useState();

  function HandleSelect(label) {
    setSelectedLabel(label);
  }

  let tabContent = <p>주제를 선택하세요</p>;

  if (selectedLabel) {
    tabContent = (
      <div style={{ backgroundColor: data[selectedLabel].backgroundColor }}>
        <h3>{data[selectedLabel].title}</h3>
        <p>{data[selectedLabel].content}</p>
        <pre>
          <code>{data[selectedLabel].code}</code>
        </pre>
      </div>
    );
  }

  return (
    <Section id="section" className="example" title="예시">
      <Tabs
        container={Section}
        buttons={
          <>
            <TabButton
              onClick={() => HandleSelect("props")}
              isSelected={selectedLabel === "props"}
            >
              데이터 전달
            </TabButton>
            <TabButton
              onClick={() => HandleSelect("component")}
              isSelected={selectedLabel === "component"}
            >
              재사용 컴포넌트
            </TabButton>
            <TabButton
              onClick={() => HandleSelect("styling")}
              isSelected={selectedLabel === "styling"}
            >
              동적 스타일링
            </TabButton>
          </>
        }
      >
        {tabContent}
      </Tabs>
    </Section>
  );
}
