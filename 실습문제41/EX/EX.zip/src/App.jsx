import React from "react";

function App() {
  return (
    <div className="app">
      <h1>React Props 연습</h1>
      <div className="card-container"></div>
    </div>
  );
}

export default App;
