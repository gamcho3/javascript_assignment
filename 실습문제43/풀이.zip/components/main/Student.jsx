function Student({ name, score, profile }) {
  return (
    <div className="student">
      <img src={profile} alt="" />
      <h3>{name}</h3>
      <p>평균점수 : {score}</p>
    </div>
  );
}

export default Student;
