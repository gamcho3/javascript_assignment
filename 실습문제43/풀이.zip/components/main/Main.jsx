import Student from "./Student";
import studentData from "../../studentData";
function Main() {
  return (
    <main className="main-content">
      <section id="home" className="section home">
        <h2>학생성적을 관리하세요</h2>
        <p>아래 학생들의 성적을 확인할 수 있습니다.</p>
      </section>

      <section id="students" className="section students">
        <h2>학생 성적 리스트</h2>
        <div className="student-list">
          <Student {...studentData[0]} />
          <Student {...studentData[1]} />
          <Student {...studentData[2]} />
          <Student {...studentData[3]} />
          <Student {...studentData[4]} />
        </div>
      </section>
    </main>
  );
}

export default Main;
