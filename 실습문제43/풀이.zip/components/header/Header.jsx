import "./Header.css";

function Header() {
  return (
    <header className="header">
      <h1>학생 관리 프로그램</h1>
      <nav>
        <ul>
          <li>
            <a href="#home">홈</a>
          </li>
          <li>
            <a href="#students">학생</a>
          </li>
          <li>
            <a href="#contact">연락</a>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
