function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2024 Student Grades Management. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
