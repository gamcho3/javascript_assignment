// src/studentData.js
const studentData = [
  {
    name: "김철수",
    score: 85,
    profile: "https://randomuser.me/api/portraits/men/37.jpg",
  },
  {
    name: "홍길동",
    score: 92,
    profile: "https://randomuser.me/api/portraits/men/38.jpg",
  },
  {
    name: "김영희",
    score: 78,
    profile: "https://randomuser.me/api/portraits/women/49.jpg",
  },
  {
    name: "박아무개",
    score: 88,
    profile: "https://randomuser.me/api/portraits/women/50.jpg",
  },
  {
    name: "김아무개",
    score: 95,
    profile: "https://randomuser.me/api/portraits/women/51.jpg",
  },
];

export default studentData;
